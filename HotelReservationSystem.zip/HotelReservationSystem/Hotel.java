import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Room> rooms;
    private List<Reservation> reservations;

    public Hotel() {
        rooms = new ArrayList<>();
        reservations = new ArrayList<>();
        // Adding some rooms for demonstration
        rooms.add(new Room(101, "Single", 50.0));
        rooms.add(new Room(102, "Double", 75.0));
        rooms.add(new Room(103, "Suite", 150.0));
    }

    public void searchAvailableRooms() {
        System.out.println("Available rooms:");
        for (Room room : rooms) {
            if (room.isAvailable()) {
                room.printDetails();
            }
        }
    }

    public Room findRoomByNumber(int roomNumber) {
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                return room;
            }
        }
        return null;
    }

    public boolean makeReservation(int roomNumber, String customerName, int numberOfNights) {
        Room room = findRoomByNumber(roomNumber);
        if (room != null && room.isAvailable()) {
            Reservation reservation = new Reservation(room, customerName, numberOfNights);
            PaymentProcessing payment = new PaymentProcessing();
            double totalCost = reservation.calculateTotalCost();
            if (payment.processPayment(totalCost)) {
                room.setAvailability(false);
                reservations.add(reservation);
                System.out.println("Reservation successful!");
                return true;
            }
        } else {
            System.out.println("Room not available or does not exist.");
        }
        return false;
    }

    public void viewReservations() {
        System.out.println("Current reservations:");
        for (Reservation reservation : reservations) {
            reservation.printBookingDetails();
            System.out.println("-------------------");
        }
    }
}