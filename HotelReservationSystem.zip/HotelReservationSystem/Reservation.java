public class Reservation {
    private Room room;
    private String customerName;
    private int numberOfNights;

    public Reservation(Room room, String customerName, int numberOfNights) {
        this.room = room;
        this.customerName = customerName;
        this.numberOfNights = numberOfNights;
    }

    public double calculateTotalCost() {
        return room.getPrice() * numberOfNights;
    }

    public void printBookingDetails() {
        System.out.println("Customer Name: " + customerName);
        System.out.println("Room Number: " + room.getRoomNumber());
        System.out.println("Room Type: " + room.getRoomType());
        System.out.println("Number of Nights: " + numberOfNights);
        System.out.println("Total Cost: $" + calculateTotalCost());
    }
}