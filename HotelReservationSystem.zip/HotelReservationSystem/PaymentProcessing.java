public class PaymentProcessing {
    public boolean processPayment(double amount) {
        System.out.println("Processing payment of $" + amount + "...");
        // Payment logic (e.g., card details verification) can be added here
        // For simplicity, assume payment is always successful
        System.out.println("Payment successful!");
        return true;
    }
}